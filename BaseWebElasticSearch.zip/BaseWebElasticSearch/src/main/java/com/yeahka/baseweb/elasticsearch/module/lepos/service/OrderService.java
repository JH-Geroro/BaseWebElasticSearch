package com.yeahka.baseweb.elasticsearch.module.lepos.service;

import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepos.entity.Order;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.data.domain.Page;

public interface OrderService {

    public Page<Order> query(CommonQueryDTO commonQuery);

    public Aggregations statistic(CommonQueryDTO commonQuery);
}
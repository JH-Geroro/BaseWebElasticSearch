package com.yeahka.baseweb.elasticsearch.gateway.system;

import com.github.isrsal.logging.RequestWrapper;
import com.github.isrsal.logging.ResponseWrapper;
import com.yeahka.baseweb.elasticsearch.common.constant.CommonConstant;
import com.yeahka.baseweb.elasticsearch.common.util.LoggerUtil;
import com.yeahka.baseweb.elasticsearch.common.util.ServletUtil;
import org.springframework.util.StringUtils;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(filterName = "commonFilter",urlPatterns = "/*")
public class CommonFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws ServletException, IOException {
        RequestWrapper requestWrapper = new RequestWrapper(Thread.currentThread().getId(), (HttpServletRequest) servletRequest);
        ResponseWrapper responseWrapper = new ResponseWrapper(Thread.currentThread().getId(), (HttpServletResponse) servletResponse);
        chain.doFilter(requestWrapper, responseWrapper);
        String method = requestWrapper.getMethod();
        String parameter = "";
        if (CommonConstant.REQUEST_METHOD_GET.equals(method)) {
            parameter = requestWrapper.getQueryString();
        } else if (CommonConstant.REQUEST_METHOD_POST.equals(method)) {
            parameter = new String(requestWrapper.toByteArray(), StringUtils.isEmpty(requestWrapper.getCharacterEncoding()) ? CommonConstant.DEFAULT_CHARSET : requestWrapper.getCharacterEncoding());
        }
        LoggerUtil.writeAccessLog("CommonFilter.doFilter() with requestUrl: {}, IP: {}, method: {}, parameter: {}", requestWrapper.getRequestURL().toString(), ServletUtil.getRealIp(requestWrapper), method, parameter);
        LoggerUtil.writeAccessLog("CommonFilter.doFilter() with response: {}", new String(responseWrapper.toByteArray(), responseWrapper.getCharacterEncoding()));
    }

    @Override
    public void destroy() {

    }
}
package com.yeahka.baseweb.elasticsearch.common.constant;

public enum RespEnum {

    SUCCESS(true, 200, "成功"),
    PARAMETER_ERROR(false, 400, "参数错误"),
    NOT_FOUND(false, 404, "资源不存在"),
    SERVER_ERROR(false, 500, "服务器异常"),
    FAIL(false, 503, "失败");

    private Boolean success;
    private Integer code;
    private String message;

    RespEnum(Boolean success, Integer code, String message) {
        this.success = success;
        this.code = code;
        this.message = message;
    }

    public Boolean getSuccess() {
        return success;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
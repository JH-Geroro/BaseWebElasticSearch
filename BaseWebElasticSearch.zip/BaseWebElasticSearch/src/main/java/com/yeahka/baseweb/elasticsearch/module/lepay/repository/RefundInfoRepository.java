package com.yeahka.baseweb.elasticsearch.module.lepay.repository;

import com.yeahka.baseweb.elasticsearch.module.lepay.entity.RefundInfo;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface RefundInfoRepository extends ElasticsearchRepository<RefundInfo, Long> {

    public Page<RefundInfo> search(QueryBuilder queryBuilder, Pageable pageable);
}
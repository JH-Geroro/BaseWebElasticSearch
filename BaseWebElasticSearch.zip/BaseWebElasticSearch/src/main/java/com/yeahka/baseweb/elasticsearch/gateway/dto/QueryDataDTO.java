package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;

import java.util.List;

public class QueryDataDTO extends BaseMeta {

    private Integer type;
    private String key;
    private String value;
    private List<String> valueList;
    private List<String> keyList;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public List<String> getValueList() {
        return valueList;
    }

    public void setValueList(List<String> valueList) {
        this.valueList = valueList;
    }

    public List<String> getKeyList() {
        return keyList;
    }

    public void setKeyList(List<String> keyList) {
        this.keyList = keyList;
    }
}
package com.yeahka.baseweb.elasticsearch.gateway.system;

import com.alibaba.fastjson.JSON;
import com.yeahka.baseweb.elasticsearch.common.constant.CommonConstant;
import com.yeahka.baseweb.elasticsearch.common.constant.RespEnum;
import com.yeahka.baseweb.elasticsearch.common.util.ServletUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.RespDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 错误控制Handler
 */
@RestControllerAdvice
public class CustomerExceptionHandler {

    private static Logger logger = LoggerFactory.getLogger(CustomerExceptionHandler.class.getSimpleName());

    /**
     * 系统错误控制器
     * 1. 打印错误信息
     * 2. 处理错误通知
     * 3. 统一返回格式
     *
     * @param httpServletRequest
     * @param httpServletResponse
     * @param ex
     * @return
     */
    @ExceptionHandler
    @ResponseBody
    public RespDTO commonException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Exception ex) {
        String method = httpServletRequest.getMethod();
        String parameter = null;
        if (CommonConstant.REQUEST_METHOD_GET.equals(method)) {
            parameter = httpServletRequest.getQueryString();
        } else if (CommonConstant.REQUEST_METHOD_POST.equals(method)) {
            parameter = JSON.toJSONString(httpServletRequest.getParameterMap());
        }
        logger.error("CustomerExceptionHandler.commonException() with requestUrl: {}, method: {}, parameter: {}, Exception: {}", httpServletRequest.getRequestURL().toString(), method, parameter, ex.getMessage(), ex);
        return new RespDTO(RespEnum.SERVER_ERROR);
    }
}
package com.yeahka.baseweb.elasticsearch.module.lepay.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Document(indexName = "lepay.t_refund_info", type = "_doc")
public class RefundInfo {

    private Long f_channel_id;
    private String f_channel_merchant_id;
    private String f_channel_provider_id;
    private Long f_create_time;
    @Id
    private Long f_id;
    private String f_merchant_id;
    private String f_merchant_refund_id;
    private String f_order_id;
    private Long f_refund_amount;
    private String f_refund_id;
    private Long f_settle_refund_amont;
    private Long f_status;
    private Long f_update_time;

    public Long getF_channel_id() {
        return f_channel_id;
    }

    public void setF_channel_id(Long f_channel_id) {
        this.f_channel_id = f_channel_id;
    }

    public String getF_channel_merchant_id() {
        return f_channel_merchant_id;
    }

    public void setF_channel_merchant_id(String f_channel_merchant_id) {
        this.f_channel_merchant_id = f_channel_merchant_id;
    }

    public String getF_channel_provider_id() {
        return f_channel_provider_id;
    }

    public void setF_channel_provider_id(String f_channel_provider_id) {
        this.f_channel_provider_id = f_channel_provider_id;
    }

    public Long getF_create_time() {
        return f_create_time;
    }

    public void setF_create_time(Long f_create_time) {
        this.f_create_time = f_create_time;
    }

    public Long getF_id() {
        return f_id;
    }

    public void setF_id(Long f_id) {
        this.f_id = f_id;
    }

    public String getF_merchant_id() {
        return f_merchant_id;
    }

    public void setF_merchant_id(String f_merchant_id) {
        this.f_merchant_id = f_merchant_id;
    }

    public String getF_merchant_refund_id() {
        return f_merchant_refund_id;
    }

    public void setF_merchant_refund_id(String f_merchant_refund_id) {
        this.f_merchant_refund_id = f_merchant_refund_id;
    }

    public String getF_order_id() {
        return f_order_id;
    }

    public void setF_order_id(String f_order_id) {
        this.f_order_id = f_order_id;
    }

    public Long getF_refund_amount() {
        return f_refund_amount;
    }

    public void setF_refund_amount(Long f_refund_amount) {
        this.f_refund_amount = f_refund_amount;
    }

    public String getF_refund_id() {
        return f_refund_id;
    }

    public void setF_refund_id(String f_refund_id) {
        this.f_refund_id = f_refund_id;
    }

    public Long getF_settle_refund_amont() {
        return f_settle_refund_amont;
    }

    public void setF_settle_refund_amont(Long f_settle_refund_amont) {
        this.f_settle_refund_amont = f_settle_refund_amont;
    }

    public Long getF_status() {
        return f_status;
    }

    public void setF_status(Long f_status) {
        this.f_status = f_status;
    }

    public Long getF_update_time() {
        return f_update_time;
    }

    public void setF_update_time(Long f_update_time) {
        this.f_update_time = f_update_time;
    }
}
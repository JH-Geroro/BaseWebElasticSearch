package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;

import java.util.List;

public class CommonQueryDTO extends BaseMeta {

    private List<QueryDataDTO> queryDataList;
    private Integer pageIndex;
    private Integer pageSize;

    public List<QueryDataDTO> getQueryDataList() {
        return queryDataList;
    }

    public void setQueryDataList(List<QueryDataDTO> queryDataList) {
        this.queryDataList = queryDataList;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
package com.yeahka.baseweb.elasticsearch.module.lepay.service;

import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OrderInfo;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.data.domain.Page;

public interface OrderInfoService {

    public Page<OrderInfo> query(CommonQueryDTO commonQuery);

    public Aggregations statistic(CommonQueryDTO commonQuery);
}
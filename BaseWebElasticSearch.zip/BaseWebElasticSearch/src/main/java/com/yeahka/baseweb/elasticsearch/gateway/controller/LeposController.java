package com.yeahka.baseweb.elasticsearch.gateway.controller;

import com.yeahka.baseweb.elasticsearch.common.constant.RespEnum;
import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.common.util.StatisticUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.OrderListDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.RespDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.TransactionOperationByMerchantListDTO;
import com.yeahka.baseweb.elasticsearch.module.lepos.entity.Order;
import com.yeahka.baseweb.elasticsearch.module.lepos.entity.TransactionOperationByMerchant;
import com.yeahka.baseweb.elasticsearch.module.lepos.service.OrderService;
import com.yeahka.baseweb.elasticsearch.module.lepos.service.TransactionOperationByMerchantService;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/lepos")
public class LeposController extends AbstractController {

    @Autowired
    private OrderService orderService;
    @Autowired
    private TransactionOperationByMerchantService transactionOperationByMerchantService;

    @RequestMapping("/order/query")
    @ResponseBody
    public RespDTO<OrderListDTO> queryOrder(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<Order> orderIterable = orderService.query(commonQuery);
        OrderListDTO dto = new OrderListDTO();
        List<Order> list = new ArrayList<>();
        for (Iterator<Order> iterator = orderIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) orderIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/order/statistic")
    @ResponseBody
    public RespDTO statisticOrder(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = orderService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }

    @RequestMapping("/transactionOperationByMerchant/query")
    @ResponseBody
    public RespDTO<TransactionOperationByMerchantListDTO> queryTransactionOperationByMerchant(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<TransactionOperationByMerchant> transactionOperationByMerchantIterable = transactionOperationByMerchantService.query(commonQuery);
        TransactionOperationByMerchantListDTO dto = new TransactionOperationByMerchantListDTO();
        List<TransactionOperationByMerchant> list = new ArrayList<>();
        for (Iterator<TransactionOperationByMerchant> iterator = transactionOperationByMerchantIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) transactionOperationByMerchantIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/transactionOperationByMerchant/statistic")
    @ResponseBody
    public RespDTO statisticTransactionOperationByMerchant(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = transactionOperationByMerchantService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }


    @RequestMapping("/transactionOperationByMerchant/sum")
    @ResponseBody
    public RespDTO sumTransactionOperationByMerchant(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Map<String, Aggregation> map = transactionOperationByMerchantService.sum(commonQuery).getAsMap();
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.covertStaticToMap(map,commonQuery));
    }
}
package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OperationInfo;

import java.util.List;

public class OperationInfoListDTO extends BaseMeta {

    private Long count;
    private List<OperationInfo> list;

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public List<OperationInfo> getList() {
        return list;
    }

    public void setList(List<OperationInfo> list) {
        this.list = list;
    }
}
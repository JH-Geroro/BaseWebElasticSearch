package com.yeahka.baseweb.elasticsearch.module.lepay.repository;

import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OrderInfo;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface OrderInfoRepository extends ElasticsearchRepository<OrderInfo, Long> {

    public Page<OrderInfo> search(QueryBuilder queryBuilder, Pageable pageable);
}
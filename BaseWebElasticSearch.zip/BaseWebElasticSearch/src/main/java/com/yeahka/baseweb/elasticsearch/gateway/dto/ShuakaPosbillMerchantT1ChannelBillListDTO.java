package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;
import com.yeahka.baseweb.elasticsearch.module.shuaka.entity.ShuakaPosbillMerchantT1ChannelBill;

import java.util.List;

public class ShuakaPosbillMerchantT1ChannelBillListDTO extends BaseMeta {

    private Integer count;
    private List<ShuakaPosbillMerchantT1ChannelBill> list;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<ShuakaPosbillMerchantT1ChannelBill> getList() {
        return list;
    }

    public void setList(List<ShuakaPosbillMerchantT1ChannelBill> list) {
        this.list = list;
    }
}
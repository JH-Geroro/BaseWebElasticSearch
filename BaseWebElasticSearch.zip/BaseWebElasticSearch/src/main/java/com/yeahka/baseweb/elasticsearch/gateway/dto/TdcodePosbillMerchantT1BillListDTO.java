package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;
import com.yeahka.baseweb.elasticsearch.module.tdcode.entity.TdcodePosbillMerchantT1Bill;

import java.util.List;

public class TdcodePosbillMerchantT1BillListDTO extends BaseMeta {

    private Integer count;
    private List<TdcodePosbillMerchantT1Bill> list;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<TdcodePosbillMerchantT1Bill> getList() {
        return list;
    }

    public void setList(List<TdcodePosbillMerchantT1Bill> list) {
        this.list = list;
    }
}
package com.yeahka.baseweb.elasticsearch.common.util;

import com.yeahka.baseweb.elasticsearch.common.constant.QueryTypeEnum;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.QueryDataDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.StatisticDTO;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.StringTerms;
import org.elasticsearch.search.aggregations.metrics.stats.InternalStats;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

public class StatisticUtil {

    public static StatisticDTO convertStatisticDTO(Aggregations aggregations) {
        StatisticDTO dto = new StatisticDTO();
        List<Map> list = new ArrayList<>();
        if (null != aggregations && null != aggregations.asMap()) {
            for (Map.Entry<String, Aggregation> entry : aggregations.asMap().entrySet()) {
                InternalSum internalSum = (InternalSum) entry.getValue();
                Map<String, Object> map = new HashMap<>();
                map.put(entry.getKey(), internalSum.getValue());
                list.add(map);
            }
        }
        dto.setList(list);
        return dto;
    }
    public static StatisticDTO covertSumToMap(Map<String, Aggregation> aggregationMap, CommonQueryDTO commonQuery) {
        StatisticDTO dto = new StatisticDTO();
        String groupName = null;
        List<String> sumNames = new ArrayList<>();
        if (null != commonQuery && !CollectionUtils.isEmpty(commonQuery.getQueryDataList())) {
            for (QueryDataDTO queryData : commonQuery.getQueryDataList()) {
                if (null == queryData.getType() || StringUtils.isEmpty(queryData.getKey())) {
                    continue;
                }
                QueryTypeEnum queryTypeEnum = QueryTypeEnum.parse(queryData.getType());
                if (null != queryTypeEnum && QueryTypeEnum.SUM.equals(queryTypeEnum)) {
                    sumNames.add(queryData.getValue());
                }
                if (null != queryTypeEnum && QueryTypeEnum.GROUP.equals(queryTypeEnum)) {
                    groupName = queryData.getValue();
                }
            }
        }
        List<Map> result = new ArrayList<>();
        StringTerms teamAgg = (StringTerms) aggregationMap.get("f_merchant_id");
        Iterator<StringTerms.Bucket> teamBucketIt = teamAgg.getBuckets().iterator();
        while (teamBucketIt.hasNext()) {
            Map<String, String> map = new HashMap<>();
            StringTerms.Bucket bucket = teamBucketIt.next();
            map.put(groupName, bucket.getKeyAsString());
            map.put("count", bucket.getDocCount() + "");
            Map subaggmap = bucket.getAggregations().asMap();
            for (String sumName : sumNames) {
                map.put(sumName, ((InternalSum) subaggmap.get(sumName)).getValue() + "");
            }
            result.add(map);
        }
        dto.setList(result);
        return dto;
    }


    public static StatisticDTO covertStaticToMap(Map<String, Aggregation> aggregationMap, CommonQueryDTO commonQuery) {
        StatisticDTO dto = new StatisticDTO();
        String sumName = null;
        if (null != commonQuery && !CollectionUtils.isEmpty(commonQuery.getQueryDataList())) {
            for (QueryDataDTO queryData : commonQuery.getQueryDataList()) {
                if (null == queryData.getType() || StringUtils.isEmpty(queryData.getKey())) {
                    continue;
                }
                QueryTypeEnum queryTypeEnum = QueryTypeEnum.parse(queryData.getType());
                if (null != queryTypeEnum && QueryTypeEnum.STAT.equals(queryTypeEnum)) {
                    sumName = queryData.getValue();
                }
            }
        }
        List<Map> result = new ArrayList<>();
        StringTerms teamAgg = (StringTerms) aggregationMap.get("f_merchant_id");
        Iterator<StringTerms.Bucket> teamBucketIt = teamAgg.getBuckets().iterator();
        while (teamBucketIt.hasNext()) {
            Map<String, String> map = new HashMap<>();
            StringTerms.Bucket bucket = teamBucketIt.next();
            map.put("merchantId", bucket.getKeyAsString());
            InternalStats internalStats = bucket.getAggregations().get(sumName);
            map.put("count", internalStats.getCount() + "");
            map.put("sum", (int) internalStats.getSum() + "");
            result.add(map);
        }
        dto.setList(result);
        return dto;
    }
}
package com.yeahka.baseweb.elasticsearch.module.lepos.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import java.util.Date;

@Document(indexName = "lepos.t_order", type = "_doc")
public class Order {

    @Id
    private String f_order_id;
    private Long f_amount;
    private String f_attach;
    private String f_callback_url;
    private String f_client_ip;
    private String f_customer_id;
    private Long f_deductpay_type;
    private Long f_deposit_commission;
    private String f_error_msg;
    private Long f_error_type;
    private String f_goods_detail;
    private String f_goods_name;
    private String f_goods_type;
    private String f_merchant_id;
    private String f_merchant_pos_no;
    private String f_merchant_shop_no;
    private Long f_pan_class;
    private Long f_pan_overseas;
    private Long f_pan_products;
    private Long f_pan_type;
    private Long f_payment_channel_id;
    private Long f_payment_mode;
    private Long f_payment_source_type;
    private String f_qrcode;
    private Long f_refund_amount;
    private String f_reserver_param;
    private String f_royalty;
    private Long f_scan_method;
    private Long f_state;
    private Long f_t0_flag;
    private String f_third_order_id;
    private Long f_third_platform_commission;
    private Date f_time;
    private Date f_update_time;
    private String f_user_name;
    private String f_voucher_id;
    private String f_voucher_info;

    public Long getF_amount() {
        return f_amount;
    }

    public void setF_amount(Long f_amount) {
        this.f_amount = f_amount;
    }

    public String getF_attach() {
        return f_attach;
    }

    public void setF_attach(String f_attach) {
        this.f_attach = f_attach;
    }

    public String getF_callback_url() {
        return f_callback_url;
    }

    public void setF_callback_url(String f_callback_url) {
        this.f_callback_url = f_callback_url;
    }

    public String getF_client_ip() {
        return f_client_ip;
    }

    public void setF_client_ip(String f_client_ip) {
        this.f_client_ip = f_client_ip;
    }

    public String getF_customer_id() {
        return f_customer_id;
    }

    public void setF_customer_id(String f_customer_id) {
        this.f_customer_id = f_customer_id;
    }

    public Long getF_deductpay_type() {
        return f_deductpay_type;
    }

    public void setF_deductpay_type(Long f_deductpay_type) {
        this.f_deductpay_type = f_deductpay_type;
    }

    public Long getF_deposit_commission() {
        return f_deposit_commission;
    }

    public void setF_deposit_commission(Long f_deposit_commission) {
        this.f_deposit_commission = f_deposit_commission;
    }

    public String getF_error_msg() {
        return f_error_msg;
    }

    public void setF_error_msg(String f_error_msg) {
        this.f_error_msg = f_error_msg;
    }

    public Long getF_error_type() {
        return f_error_type;
    }

    public void setF_error_type(Long f_error_type) {
        this.f_error_type = f_error_type;
    }

    public String getF_goods_detail() {
        return f_goods_detail;
    }

    public void setF_goods_detail(String f_goods_detail) {
        this.f_goods_detail = f_goods_detail;
    }

    public String getF_goods_name() {
        return f_goods_name;
    }

    public void setF_goods_name(String f_goods_name) {
        this.f_goods_name = f_goods_name;
    }

    public String getF_goods_type() {
        return f_goods_type;
    }

    public void setF_goods_type(String f_goods_type) {
        this.f_goods_type = f_goods_type;
    }

    public String getF_merchant_id() {
        return f_merchant_id;
    }

    public void setF_merchant_id(String f_merchant_id) {
        this.f_merchant_id = f_merchant_id;
    }

    public String getF_merchant_pos_no() {
        return f_merchant_pos_no;
    }

    public void setF_merchant_pos_no(String f_merchant_pos_no) {
        this.f_merchant_pos_no = f_merchant_pos_no;
    }

    public String getF_merchant_shop_no() {
        return f_merchant_shop_no;
    }

    public void setF_merchant_shop_no(String f_merchant_shop_no) {
        this.f_merchant_shop_no = f_merchant_shop_no;
    }

    public String getF_order_id() {
        return f_order_id;
    }

    public void setF_order_id(String f_order_id) {
        this.f_order_id = f_order_id;
    }

    public Long getF_pan_class() {
        return f_pan_class;
    }

    public void setF_pan_class(Long f_pan_class) {
        this.f_pan_class = f_pan_class;
    }

    public Long getF_pan_overseas() {
        return f_pan_overseas;
    }

    public void setF_pan_overseas(Long f_pan_overseas) {
        this.f_pan_overseas = f_pan_overseas;
    }

    public Long getF_pan_products() {
        return f_pan_products;
    }

    public void setF_pan_products(Long f_pan_products) {
        this.f_pan_products = f_pan_products;
    }

    public Long getF_pan_type() {
        return f_pan_type;
    }

    public void setF_pan_type(Long f_pan_type) {
        this.f_pan_type = f_pan_type;
    }

    public Long getF_payment_channel_id() {
        return f_payment_channel_id;
    }

    public void setF_payment_channel_id(Long f_payment_channel_id) {
        this.f_payment_channel_id = f_payment_channel_id;
    }

    public Long getF_payment_mode() {
        return f_payment_mode;
    }

    public void setF_payment_mode(Long f_payment_mode) {
        this.f_payment_mode = f_payment_mode;
    }

    public Long getF_payment_source_type() {
        return f_payment_source_type;
    }

    public void setF_payment_source_type(Long f_payment_source_type) {
        this.f_payment_source_type = f_payment_source_type;
    }

    public String getF_qrcode() {
        return f_qrcode;
    }

    public void setF_qrcode(String f_qrcode) {
        this.f_qrcode = f_qrcode;
    }

    public Long getF_refund_amount() {
        return f_refund_amount;
    }

    public void setF_refund_amount(Long f_refund_amount) {
        this.f_refund_amount = f_refund_amount;
    }

    public String getF_reserver_param() {
        return f_reserver_param;
    }

    public void setF_reserver_param(String f_reserver_param) {
        this.f_reserver_param = f_reserver_param;
    }

    public String getF_royalty() {
        return f_royalty;
    }

    public void setF_royalty(String f_royalty) {
        this.f_royalty = f_royalty;
    }

    public Long getF_scan_method() {
        return f_scan_method;
    }

    public void setF_scan_method(Long f_scan_method) {
        this.f_scan_method = f_scan_method;
    }

    public Long getF_state() {
        return f_state;
    }

    public void setF_state(Long f_state) {
        this.f_state = f_state;
    }

    public Long getF_t0_flag() {
        return f_t0_flag;
    }

    public void setF_t0_flag(Long f_t0_flag) {
        this.f_t0_flag = f_t0_flag;
    }

    public String getF_third_order_id() {
        return f_third_order_id;
    }

    public void setF_third_order_id(String f_third_order_id) {
        this.f_third_order_id = f_third_order_id;
    }

    public Long getF_third_platform_commission() {
        return f_third_platform_commission;
    }

    public void setF_third_platform_commission(Long f_third_platform_commission) {
        this.f_third_platform_commission = f_third_platform_commission;
    }

    public Date getF_time() {
        return f_time;
    }

    public void setF_time(Date f_time) {
        this.f_time = f_time;
    }

    public Date getF_update_time() {
        return f_update_time;
    }

    public void setF_update_time(Date f_update_time) {
        this.f_update_time = f_update_time;
    }

    public String getF_user_name() {
        return f_user_name;
    }

    public void setF_user_name(String f_user_name) {
        this.f_user_name = f_user_name;
    }

    public String getF_voucher_id() {
        return f_voucher_id;
    }

    public void setF_voucher_id(String f_voucher_id) {
        this.f_voucher_id = f_voucher_id;
    }

    public String getF_voucher_info() {
        return f_voucher_info;
    }

    public void setF_voucher_info(String f_voucher_info) {
        this.f_voucher_info = f_voucher_info;
    }
}
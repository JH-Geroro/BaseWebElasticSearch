package com.yeahka.baseweb.elasticsearch.gateway.controller;

import com.yeahka.baseweb.elasticsearch.common.constant.RespEnum;
import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.common.util.StatisticUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.RespDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.TdcodePosbillMerchantT1BillListDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.TdcodePosbillMerchantT1ChannelBillListDTO;
import com.yeahka.baseweb.elasticsearch.module.tdcode.entity.TdcodePosbillMerchantT1Bill;
import com.yeahka.baseweb.elasticsearch.module.tdcode.entity.TdcodePosbillMerchantT1ChannelBill;
import com.yeahka.baseweb.elasticsearch.module.tdcode.service.TdcodePosbillMerchantT1BillService;
import com.yeahka.baseweb.elasticsearch.module.tdcode.service.TdcodePosbillMerchantT1ChannelBillService;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@RestController
@RequestMapping("/tdcode")
public class TdcodeController extends AbstractController {

    @Autowired
    private TdcodePosbillMerchantT1BillService tdcodePosbillMerchantT1BillService;
    @Autowired
    private TdcodePosbillMerchantT1ChannelBillService tdcodePosbillMerchantT1ChannelBillService;

    @RequestMapping("/posbill/merchantT1Bill/query")
    @ResponseBody
    public RespDTO<TdcodePosbillMerchantT1BillListDTO> queryPosbillMerchantT1Bill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<TdcodePosbillMerchantT1Bill> tdcodePosbillMerchantT1BillIterable = tdcodePosbillMerchantT1BillService.query(commonQuery);
        TdcodePosbillMerchantT1BillListDTO dto = new TdcodePosbillMerchantT1BillListDTO();
        List<TdcodePosbillMerchantT1Bill> list = new ArrayList<>();
        for (Iterator<TdcodePosbillMerchantT1Bill> iterator = tdcodePosbillMerchantT1BillIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) tdcodePosbillMerchantT1BillIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/posbill/merchantT1Bill/statistic")
    @ResponseBody
    public RespDTO statisticPosbillMerchantT1Bill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = tdcodePosbillMerchantT1BillService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }

    @RequestMapping("/posbill/merchantT1ChannelBill/query")
    @ResponseBody
    public RespDTO<TdcodePosbillMerchantT1ChannelBillListDTO> queryPosbillMerchantT1ChannelBill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<TdcodePosbillMerchantT1ChannelBill> tdcodePosbillMerchantT1ChannelBillIterable = tdcodePosbillMerchantT1ChannelBillService.query(commonQuery);
        TdcodePosbillMerchantT1ChannelBillListDTO dto = new TdcodePosbillMerchantT1ChannelBillListDTO();
        List<TdcodePosbillMerchantT1ChannelBill> list = new ArrayList<>();
        for (Iterator<TdcodePosbillMerchantT1ChannelBill> iterator = tdcodePosbillMerchantT1ChannelBillIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) tdcodePosbillMerchantT1ChannelBillIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/posbill/merchantT1ChannelBill/statistic")
    @ResponseBody
    public RespDTO statisticPosbillMerchantT1ChannelBill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = tdcodePosbillMerchantT1ChannelBillService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }
}
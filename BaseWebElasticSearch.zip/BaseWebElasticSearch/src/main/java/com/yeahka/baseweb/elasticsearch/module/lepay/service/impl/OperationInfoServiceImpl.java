package com.yeahka.baseweb.elasticsearch.module.lepay.service.impl;

import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OperationInfo;
import com.yeahka.baseweb.elasticsearch.module.lepay.repository.OperationInfoRepository;
import com.yeahka.baseweb.elasticsearch.module.lepay.service.OperationInfoService;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Service;

@Service
public class OperationInfoServiceImpl implements OperationInfoService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;
    @Autowired
    private OperationInfoRepository operationInfoRepository;

    @Override
    public Page<OperationInfo> query(CommonQueryDTO commonQuery) {
        return operationInfoRepository.search(QueryUtil.convertQuery(commonQuery), PageRequest.of(commonQuery.getPageIndex(), commonQuery.getPageSize()));
    }

    @Override
    public Aggregations statistic(CommonQueryDTO commonQuery) {
        return elasticsearchTemplate.query(QueryUtil.convertStatistic(commonQuery, "lepay.t_operation_info", "_doc"), new ResultsExtractor<Aggregations>() {
            @Override
            public Aggregations extract(SearchResponse response) {
                return response.getAggregations();
            }
        });
    }
}
package com.yeahka.baseweb.elasticsearch.module.lepay.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Document(indexName = "lepay.t_operation_info", type = "_doc")
public class OperationInfo {

    @Id
    private Long f_id;
    private Long f_operation_type;
    private String f_order_id;
    private Long f_trade_type;
    private String f_transaction_data;
    private String f_merchant_id;
    private Long f_create_time;
    private Long f_update_time;
    private String order_id_and_type;

    public Long getF_id() {
        return f_id;
    }

    public void setF_id(Long f_id) {
        this.f_id = f_id;
    }

    public Long getF_operation_type() {
        return f_operation_type;
    }

    public void setF_operation_type(Long f_operation_type) {
        this.f_operation_type = f_operation_type;
    }

    public String getF_order_id() {
        return f_order_id;
    }

    public void setF_order_id(String f_order_id) {
        this.f_order_id = f_order_id;
    }

    public Long getF_trade_type() {
        return f_trade_type;
    }

    public void setF_trade_type(Long f_trade_type) {
        this.f_trade_type = f_trade_type;
    }

    public String getF_transaction_data() {
        return f_transaction_data;
    }

    public void setF_transaction_data(String f_transaction_data) {
        this.f_transaction_data = f_transaction_data;
    }

    public String getF_merchant_id() {
        return f_merchant_id;
    }

    public void setF_merchant_id(String f_merchant_id) {
        this.f_merchant_id = f_merchant_id;
    }

    public Long getF_create_time() {
        return f_create_time;
    }

    public void setF_create_time(Long f_create_time) {
        this.f_create_time = f_create_time;
    }

    public Long getF_update_time() {
        return f_update_time;
    }

    public void setF_update_time(Long f_update_time) {
        this.f_update_time = f_update_time;
    }

    public String getOrder_id_and_type() {
        return order_id_and_type;
    }

    public void setOrder_id_and_type(String order_id_and_type) {
        this.order_id_and_type = order_id_and_type;
    }
}
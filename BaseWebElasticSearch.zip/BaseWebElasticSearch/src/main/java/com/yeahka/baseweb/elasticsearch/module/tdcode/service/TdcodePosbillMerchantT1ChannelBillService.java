package com.yeahka.baseweb.elasticsearch.module.tdcode.service;

import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.tdcode.entity.TdcodePosbillMerchantT1ChannelBill;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.data.domain.Page;

public interface TdcodePosbillMerchantT1ChannelBillService {

    public Page<TdcodePosbillMerchantT1ChannelBill> query(CommonQueryDTO commonQuery);

    public Aggregations statistic(CommonQueryDTO commonQuery);
}
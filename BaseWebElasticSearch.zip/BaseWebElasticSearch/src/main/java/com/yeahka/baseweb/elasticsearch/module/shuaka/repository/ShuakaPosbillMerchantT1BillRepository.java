package com.yeahka.baseweb.elasticsearch.module.shuaka.repository;

import com.yeahka.baseweb.elasticsearch.module.shuaka.entity.ShuakaPosbillMerchantT1Bill;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface ShuakaPosbillMerchantT1BillRepository extends ElasticsearchRepository<ShuakaPosbillMerchantT1Bill, Long> {

    public Page<ShuakaPosbillMerchantT1Bill> search(QueryBuilder queryBuilder, Pageable pageable);
}
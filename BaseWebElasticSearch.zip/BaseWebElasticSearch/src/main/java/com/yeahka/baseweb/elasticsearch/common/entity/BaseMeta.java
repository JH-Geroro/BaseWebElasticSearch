package com.yeahka.baseweb.elasticsearch.common.entity;

import com.alibaba.fastjson.JSON;

public class BaseMeta {

    public String toString() {
        return JSON.toJSONString(this);
    }
}
package com.yeahka.baseweb.elasticsearch.module.lepos.repository;

import com.yeahka.baseweb.elasticsearch.module.lepos.entity.TransactionOperationByMerchant;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface TransactionOperationByMerchantRepository extends ElasticsearchRepository<TransactionOperationByMerchant, Long> {

    public Page<TransactionOperationByMerchant> search(QueryBuilder queryBuilder, Pageable pageable);
}
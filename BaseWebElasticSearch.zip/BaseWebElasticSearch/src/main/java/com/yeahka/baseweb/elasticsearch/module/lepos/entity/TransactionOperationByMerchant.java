package com.yeahka.baseweb.elasticsearch.module.lepos.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import java.util.Date;

@Document(indexName = "lepos.t_transaction_operation_by_merchant", type = "_doc")
public class TransactionOperationByMerchant {

    private Long f_agent_id_1g;
    private Long f_amount;
    private Long f_app_type;
    private String f_card_bank;
    private String f_card_id;
    private String f_card_sequence_number;
    private Long f_card_type;
    private String f_channel_authorize_code;
    private String f_channel_batch_number;
    private String f_channel_error_code;
    private String f_channel_order_id;
    private String f_channel_reference_number;
    private String f_channel_settle_date;
    private Long f_coupon_amount;
    private String f_encrypt_card_id;
    private Long f_flag;
    private String f_ic_aid;
    private String f_ic_atc;
    private String f_ic_field_55;
    private String f_ic_tc;
    private String f_latitude;
    private String f_longitude;
    private String f_merchant_id;
    private String f_merchant_refund_id;
    private String f_mobile_id;
    private Long f_no_passwd_flag;
    private Long f_operation_type;
    private Long f_order_amount;
    private String f_order_id;
    private Long f_pan_class;
    private Long f_pan_overseas;
    private Long f_pan_products;
    private Long f_pan_type;
    private Long f_payment_channel_id;
    private String f_payment_channel_merchant_id;
    private String f_payment_channel_terminal_id;
    private String f_pinpad_id;
    private String f_pinpad_uuid;
    private String f_receive_bank_code;
    private Date f_third_time;
    private Date f_time;
    @Id
    private String f_transaction_id;
    private String f_user_name;

    public Long getF_agent_id_1g() {
        return f_agent_id_1g;
    }

    public void setF_agent_id_1g(Long f_agent_id_1g) {
        this.f_agent_id_1g = f_agent_id_1g;
    }

    public Long getF_amount() {
        return f_amount;
    }

    public void setF_amount(Long f_amount) {
        this.f_amount = f_amount;
    }

    public Long getF_app_type() {
        return f_app_type;
    }

    public void setF_app_type(Long f_app_type) {
        this.f_app_type = f_app_type;
    }

    public String getF_card_bank() {
        return f_card_bank;
    }

    public void setF_card_bank(String f_card_bank) {
        this.f_card_bank = f_card_bank;
    }

    public String getF_card_id() {
        return f_card_id;
    }

    public void setF_card_id(String f_card_id) {
        this.f_card_id = f_card_id;
    }

    public String getF_card_sequence_number() {
        return f_card_sequence_number;
    }

    public void setF_card_sequence_number(String f_card_sequence_number) {
        this.f_card_sequence_number = f_card_sequence_number;
    }

    public Long getF_card_type() {
        return f_card_type;
    }

    public void setF_card_type(Long f_card_type) {
        this.f_card_type = f_card_type;
    }

    public String getF_channel_authorize_code() {
        return f_channel_authorize_code;
    }

    public void setF_channel_authorize_code(String f_channel_authorize_code) {
        this.f_channel_authorize_code = f_channel_authorize_code;
    }

    public String getF_channel_batch_number() {
        return f_channel_batch_number;
    }

    public void setF_channel_batch_number(String f_channel_batch_number) {
        this.f_channel_batch_number = f_channel_batch_number;
    }

    public String getF_channel_error_code() {
        return f_channel_error_code;
    }

    public void setF_channel_error_code(String f_channel_error_code) {
        this.f_channel_error_code = f_channel_error_code;
    }

    public String getF_channel_order_id() {
        return f_channel_order_id;
    }

    public void setF_channel_order_id(String f_channel_order_id) {
        this.f_channel_order_id = f_channel_order_id;
    }

    public String getF_channel_reference_number() {
        return f_channel_reference_number;
    }

    public void setF_channel_reference_number(String f_channel_reference_number) {
        this.f_channel_reference_number = f_channel_reference_number;
    }

    public String getF_channel_settle_date() {
        return f_channel_settle_date;
    }

    public void setF_channel_settle_date(String f_channel_settle_date) {
        this.f_channel_settle_date = f_channel_settle_date;
    }

    public Long getF_coupon_amount() {
        return f_coupon_amount;
    }

    public void setF_coupon_amount(Long f_coupon_amount) {
        this.f_coupon_amount = f_coupon_amount;
    }

    public String getF_encrypt_card_id() {
        return f_encrypt_card_id;
    }

    public void setF_encrypt_card_id(String f_encrypt_card_id) {
        this.f_encrypt_card_id = f_encrypt_card_id;
    }

    public Long getF_flag() {
        return f_flag;
    }

    public void setF_flag(Long f_flag) {
        this.f_flag = f_flag;
    }

    public String getF_ic_aid() {
        return f_ic_aid;
    }

    public void setF_ic_aid(String f_ic_aid) {
        this.f_ic_aid = f_ic_aid;
    }

    public String getF_ic_atc() {
        return f_ic_atc;
    }

    public void setF_ic_atc(String f_ic_atc) {
        this.f_ic_atc = f_ic_atc;
    }

    public String getF_ic_field_55() {
        return f_ic_field_55;
    }

    public void setF_ic_field_55(String f_ic_field_55) {
        this.f_ic_field_55 = f_ic_field_55;
    }

    public String getF_ic_tc() {
        return f_ic_tc;
    }

    public void setF_ic_tc(String f_ic_tc) {
        this.f_ic_tc = f_ic_tc;
    }

    public String getF_latitude() {
        return f_latitude;
    }

    public void setF_latitude(String f_latitude) {
        this.f_latitude = f_latitude;
    }

    public String getF_longitude() {
        return f_longitude;
    }

    public void setF_longitude(String f_longitude) {
        this.f_longitude = f_longitude;
    }

    public String getF_merchant_id() {
        return f_merchant_id;
    }

    public void setF_merchant_id(String f_merchant_id) {
        this.f_merchant_id = f_merchant_id;
    }

    public String getF_merchant_refund_id() {
        return f_merchant_refund_id;
    }

    public void setF_merchant_refund_id(String f_merchant_refund_id) {
        this.f_merchant_refund_id = f_merchant_refund_id;
    }

    public String getF_mobile_id() {
        return f_mobile_id;
    }

    public void setF_mobile_id(String f_mobile_id) {
        this.f_mobile_id = f_mobile_id;
    }

    public Long getF_no_passwd_flag() {
        return f_no_passwd_flag;
    }

    public void setF_no_passwd_flag(Long f_no_passwd_flag) {
        this.f_no_passwd_flag = f_no_passwd_flag;
    }

    public Long getF_operation_type() {
        return f_operation_type;
    }

    public void setF_operation_type(Long f_operation_type) {
        this.f_operation_type = f_operation_type;
    }

    public Long getF_order_amount() {
        return f_order_amount;
    }

    public void setF_order_amount(Long f_order_amount) {
        this.f_order_amount = f_order_amount;
    }

    public String getF_order_id() {
        return f_order_id;
    }

    public void setF_order_id(String f_order_id) {
        this.f_order_id = f_order_id;
    }

    public Long getF_pan_class() {
        return f_pan_class;
    }

    public void setF_pan_class(Long f_pan_class) {
        this.f_pan_class = f_pan_class;
    }

    public Long getF_pan_overseas() {
        return f_pan_overseas;
    }

    public void setF_pan_overseas(Long f_pan_overseas) {
        this.f_pan_overseas = f_pan_overseas;
    }

    public Long getF_pan_products() {
        return f_pan_products;
    }

    public void setF_pan_products(Long f_pan_products) {
        this.f_pan_products = f_pan_products;
    }

    public Long getF_pan_type() {
        return f_pan_type;
    }

    public void setF_pan_type(Long f_pan_type) {
        this.f_pan_type = f_pan_type;
    }

    public Long getF_payment_channel_id() {
        return f_payment_channel_id;
    }

    public void setF_payment_channel_id(Long f_payment_channel_id) {
        this.f_payment_channel_id = f_payment_channel_id;
    }

    public String getF_payment_channel_merchant_id() {
        return f_payment_channel_merchant_id;
    }

    public void setF_payment_channel_merchant_id(String f_payment_channel_merchant_id) {
        this.f_payment_channel_merchant_id = f_payment_channel_merchant_id;
    }

    public String getF_payment_channel_terminal_id() {
        return f_payment_channel_terminal_id;
    }

    public void setF_payment_channel_terminal_id(String f_payment_channel_terminal_id) {
        this.f_payment_channel_terminal_id = f_payment_channel_terminal_id;
    }

    public String getF_pinpad_id() {
        return f_pinpad_id;
    }

    public void setF_pinpad_id(String f_pinpad_id) {
        this.f_pinpad_id = f_pinpad_id;
    }

    public String getF_pinpad_uuid() {
        return f_pinpad_uuid;
    }

    public void setF_pinpad_uuid(String f_pinpad_uuid) {
        this.f_pinpad_uuid = f_pinpad_uuid;
    }

    public String getF_receive_bank_code() {
        return f_receive_bank_code;
    }

    public void setF_receive_bank_code(String f_receive_bank_code) {
        this.f_receive_bank_code = f_receive_bank_code;
    }

    public Date getF_third_time() {
        return f_third_time;
    }

    public void setF_third_time(Date f_third_time) {
        this.f_third_time = f_third_time;
    }

    public Date getF_time() {
        return f_time;
    }

    public void setF_time(Date f_time) {
        this.f_time = f_time;
    }

    public String getF_transaction_id() {
        return f_transaction_id;
    }

    public void setF_transaction_id(String f_transaction_id) {
        this.f_transaction_id = f_transaction_id;
    }

    public String getF_user_name() {
        return f_user_name;
    }

    public void setF_user_name(String f_user_name) {
        this.f_user_name = f_user_name;
    }
}
package com.yeahka.baseweb.elasticsearch.module.lepay.service;

import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OperationInfo;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.data.domain.Page;

public interface OperationInfoService {

    public Page<OperationInfo> query(CommonQueryDTO commonQuery);

    public Aggregations statistic(CommonQueryDTO commonQuery);
}
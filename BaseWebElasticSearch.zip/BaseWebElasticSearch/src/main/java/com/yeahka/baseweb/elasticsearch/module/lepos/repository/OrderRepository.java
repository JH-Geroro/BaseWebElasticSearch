package com.yeahka.baseweb.elasticsearch.module.lepos.repository;

import com.yeahka.baseweb.elasticsearch.module.lepos.entity.Order;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface OrderRepository extends ElasticsearchRepository<Order, Long> {

    public Page<Order> search(QueryBuilder queryBuilder, Pageable pageable);
}
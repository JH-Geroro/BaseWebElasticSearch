package com.yeahka.baseweb.elasticsearch.module.lepay.repository;

import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OperationInfo;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface OperationInfoRepository extends ElasticsearchRepository<OperationInfo, Long> {

    public Page<OperationInfo> search(QueryBuilder queryBuilder, Pageable pageable);
}
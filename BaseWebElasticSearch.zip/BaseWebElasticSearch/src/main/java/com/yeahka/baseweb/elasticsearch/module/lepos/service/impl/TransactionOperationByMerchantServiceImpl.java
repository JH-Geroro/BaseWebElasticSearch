package com.yeahka.baseweb.elasticsearch.module.lepos.service.impl;

import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepos.entity.TransactionOperationByMerchant;
import com.yeahka.baseweb.elasticsearch.module.lepos.repository.TransactionOperationByMerchantRepository;
import com.yeahka.baseweb.elasticsearch.module.lepos.service.TransactionOperationByMerchantService;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Service;

@Service
public class TransactionOperationByMerchantServiceImpl implements TransactionOperationByMerchantService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;
    @Autowired
    private TransactionOperationByMerchantRepository transactionOperationByMerchantRepository;

    @Override
    public Page<TransactionOperationByMerchant> query(CommonQueryDTO commonQuery) {
        return transactionOperationByMerchantRepository.search(QueryUtil.convertQuery(commonQuery), PageRequest.of(commonQuery.getPageIndex(), commonQuery.getPageSize()));
    }

    @Override
    public Aggregations statistic(CommonQueryDTO commonQuery) {
        return elasticsearchTemplate.query(QueryUtil.convertStatistic(commonQuery, "lepos.t_transaction_operation_by_merchant", "_doc"), new ResultsExtractor<Aggregations>() {
            @Override
            public Aggregations extract(SearchResponse response) {
                return response.getAggregations();
            }
        });
    }

    @Override
    public Aggregations sum(CommonQueryDTO commonQuery) {
        return elasticsearchTemplate.query(QueryUtil.convertStat(commonQuery, "lepos.t_transaction_operation_by_merchant", "_doc"), new ResultsExtractor<Aggregations>() {
            @Override
            public Aggregations extract(SearchResponse response) {
                return response.getAggregations();
            }
        });
    }
}
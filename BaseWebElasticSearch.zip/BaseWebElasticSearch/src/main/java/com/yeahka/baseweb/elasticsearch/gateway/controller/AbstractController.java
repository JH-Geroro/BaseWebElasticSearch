package com.yeahka.baseweb.elasticsearch.gateway.controller;

public abstract class AbstractController {

}
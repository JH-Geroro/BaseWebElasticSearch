package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;
import com.yeahka.baseweb.elasticsearch.module.shuaka.entity.ShuakaPosbillMerchantT1Bill;

import java.util.List;

public class ShuakaPosbillMerchantT1BillListDTO extends BaseMeta {

    private Integer count;
    private List<ShuakaPosbillMerchantT1Bill> list;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<ShuakaPosbillMerchantT1Bill> getList() {
        return list;
    }

    public void setList(List<ShuakaPosbillMerchantT1Bill> list) {
        this.list = list;
    }
}
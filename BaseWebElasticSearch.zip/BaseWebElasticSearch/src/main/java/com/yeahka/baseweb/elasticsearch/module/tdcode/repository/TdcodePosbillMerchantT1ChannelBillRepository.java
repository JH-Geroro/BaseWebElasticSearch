package com.yeahka.baseweb.elasticsearch.module.tdcode.repository;

import com.yeahka.baseweb.elasticsearch.module.tdcode.entity.TdcodePosbillMerchantT1ChannelBill;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface TdcodePosbillMerchantT1ChannelBillRepository extends ElasticsearchRepository<TdcodePosbillMerchantT1ChannelBill, Long> {

    public Page<TdcodePosbillMerchantT1ChannelBill> search(QueryBuilder queryBuilder, Pageable pageable);
}
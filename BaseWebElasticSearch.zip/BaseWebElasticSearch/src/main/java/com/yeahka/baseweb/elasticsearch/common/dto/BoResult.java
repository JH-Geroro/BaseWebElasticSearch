package com.yeahka.baseweb.elasticsearch.common.dto;

import com.yeahka.baseweb.elasticsearch.common.constant.RespEnum;
import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;

public class BoResult<T extends BaseMeta> extends BaseMeta {

    private Boolean success;
    private Integer code;
    private T data;
    private String message;

    public BoResult(RespEnum respEnum) {
        this.success = respEnum.getSuccess();
        this.code = respEnum.getCode();
        this.data = null;
        this.message = respEnum.getMessage();
    }

    public BoResult(RespEnum respEnum, T data) {
        this.success = respEnum.getSuccess();
        this.code = respEnum.getCode();
        this.data = data;
        this.message = respEnum.getMessage();
    }

    public BoResult(RespEnum respEnum, T data, String message) {
        this.success = respEnum.getSuccess();
        this.code = respEnum.getCode();
        this.data = data;
        this.message = message;
    }

    public BoResult(Boolean success, Integer code, T data, String message) {
        this.success = success;
        this.code = code;
        this.data = data;
        this.message = message;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
package com.yeahka.baseweb.elasticsearch.common.constant;

/**
 * 查询类型
 */
public enum QueryTypeEnum {

    IS_NOT(0),
    IS(1),
    LIKE(2),
    GREATER(3),
    LESS(4),
    IN(5),
    NOT_IN(6),
    SUM(7),
    GROUP(8),
    STAT(9),
    OR(10);

    private Integer type;

    QueryTypeEnum(Integer type) {
        this.type = type;
    }

    public static QueryTypeEnum parse(Integer type) {
        if (null != type) {
            for (QueryTypeEnum queryTypeEnum : QueryTypeEnum.values()) {
                if (type.intValue() == queryTypeEnum.getType().intValue()) {
                    return queryTypeEnum;
                }
            }
        }
        return null;
    }

    public Integer getType() {
        return type;
    }
}
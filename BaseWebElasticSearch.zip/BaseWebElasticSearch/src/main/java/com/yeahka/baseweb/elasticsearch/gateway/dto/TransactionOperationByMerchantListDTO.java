package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;
import com.yeahka.baseweb.elasticsearch.module.lepos.entity.TransactionOperationByMerchant;

import java.util.List;

public class TransactionOperationByMerchantListDTO extends BaseMeta {

    private Integer count;
    private List<TransactionOperationByMerchant> list;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<TransactionOperationByMerchant> getList() {
        return list;
    }

    public void setList(List<TransactionOperationByMerchant> list) {
        this.list = list;
    }
}
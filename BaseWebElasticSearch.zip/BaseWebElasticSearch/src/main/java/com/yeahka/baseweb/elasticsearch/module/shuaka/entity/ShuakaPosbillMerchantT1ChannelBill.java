package com.yeahka.baseweb.elasticsearch.module.shuaka.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import java.util.Date;

@Document(indexName = "shuaka.posbill.t_merchant_t1_channel_bill", type = "_doc")
public class ShuakaPosbillMerchantT1ChannelBill {

    private String f_agent_id;
    private Long f_amount;
    private Long f_channel_commission;
    private Long f_channel_commission_ext;
    private Long f_channel_id;
    private Long f_channel_settle_amount;
    private Long f_channel_settle_amount_ext;
    private Date f_create_time;
    private Date f_end_time;
    private Long f_fee_rate;
    private Long f_gross_profit_amount;
    private Long f_gross_profit_amount_ext;
    private Long f_in_count;
    private String f_keep_accounts_code;
    private Long f_merchant_commission;
    private Long f_merchant_commission_ext;
    private String f_merchant_id;
    private String f_merchant_name;
    private Long f_merchant_return_amount;
    private Long f_merchant_return_amount_ext;
    private Long f_merchant_settle_amount;
    private Long f_merchant_settle_amount_ext;
    @Id
    private String f_order_id;
    private Long f_out_count;
    private String f_royalty;
    private Date f_start_time;
    private Long f_state;
    private Long f_toagent_profit;
    private Long f_toagent_profit_ext;
    private Long f_tome_profit;
    private Long f_tome_profit_ext;
    private Date f_update_time;

    public String getF_agent_id() {
        return f_agent_id;
    }

    public void setF_agent_id(String f_agent_id) {
        this.f_agent_id = f_agent_id;
    }

    public Long getF_amount() {
        return f_amount;
    }

    public void setF_amount(Long f_amount) {
        this.f_amount = f_amount;
    }

    public Long getF_channel_commission() {
        return f_channel_commission;
    }

    public void setF_channel_commission(Long f_channel_commission) {
        this.f_channel_commission = f_channel_commission;
    }

    public Long getF_channel_commission_ext() {
        return f_channel_commission_ext;
    }

    public void setF_channel_commission_ext(Long f_channel_commission_ext) {
        this.f_channel_commission_ext = f_channel_commission_ext;
    }

    public Long getF_channel_id() {
        return f_channel_id;
    }

    public void setF_channel_id(Long f_channel_id) {
        this.f_channel_id = f_channel_id;
    }

    public Long getF_channel_settle_amount() {
        return f_channel_settle_amount;
    }

    public void setF_channel_settle_amount(Long f_channel_settle_amount) {
        this.f_channel_settle_amount = f_channel_settle_amount;
    }

    public Long getF_channel_settle_amount_ext() {
        return f_channel_settle_amount_ext;
    }

    public void setF_channel_settle_amount_ext(Long f_channel_settle_amount_ext) {
        this.f_channel_settle_amount_ext = f_channel_settle_amount_ext;
    }

    public Date getF_create_time() {
        return f_create_time;
    }

    public void setF_create_time(Date f_create_time) {
        this.f_create_time = f_create_time;
    }

    public Date getF_end_time() {
        return f_end_time;
    }

    public void setF_end_time(Date f_end_time) {
        this.f_end_time = f_end_time;
    }

    public Long getF_fee_rate() {
        return f_fee_rate;
    }

    public void setF_fee_rate(Long f_fee_rate) {
        this.f_fee_rate = f_fee_rate;
    }

    public Long getF_gross_profit_amount() {
        return f_gross_profit_amount;
    }

    public void setF_gross_profit_amount(Long f_gross_profit_amount) {
        this.f_gross_profit_amount = f_gross_profit_amount;
    }

    public Long getF_gross_profit_amount_ext() {
        return f_gross_profit_amount_ext;
    }

    public void setF_gross_profit_amount_ext(Long f_gross_profit_amount_ext) {
        this.f_gross_profit_amount_ext = f_gross_profit_amount_ext;
    }

    public Long getF_in_count() {
        return f_in_count;
    }

    public void setF_in_count(Long f_in_count) {
        this.f_in_count = f_in_count;
    }

    public String getF_keep_accounts_code() {
        return f_keep_accounts_code;
    }

    public void setF_keep_accounts_code(String f_keep_accounts_code) {
        this.f_keep_accounts_code = f_keep_accounts_code;
    }

    public Long getF_merchant_commission() {
        return f_merchant_commission;
    }

    public void setF_merchant_commission(Long f_merchant_commission) {
        this.f_merchant_commission = f_merchant_commission;
    }

    public Long getF_merchant_commission_ext() {
        return f_merchant_commission_ext;
    }

    public void setF_merchant_commission_ext(Long f_merchant_commission_ext) {
        this.f_merchant_commission_ext = f_merchant_commission_ext;
    }

    public String getF_merchant_id() {
        return f_merchant_id;
    }

    public void setF_merchant_id(String f_merchant_id) {
        this.f_merchant_id = f_merchant_id;
    }

    public String getF_merchant_name() {
        return f_merchant_name;
    }

    public void setF_merchant_name(String f_merchant_name) {
        this.f_merchant_name = f_merchant_name;
    }

    public Long getF_merchant_return_amount() {
        return f_merchant_return_amount;
    }

    public void setF_merchant_return_amount(Long f_merchant_return_amount) {
        this.f_merchant_return_amount = f_merchant_return_amount;
    }

    public Long getF_merchant_return_amount_ext() {
        return f_merchant_return_amount_ext;
    }

    public void setF_merchant_return_amount_ext(Long f_merchant_return_amount_ext) {
        this.f_merchant_return_amount_ext = f_merchant_return_amount_ext;
    }

    public Long getF_merchant_settle_amount() {
        return f_merchant_settle_amount;
    }

    public void setF_merchant_settle_amount(Long f_merchant_settle_amount) {
        this.f_merchant_settle_amount = f_merchant_settle_amount;
    }

    public Long getF_merchant_settle_amount_ext() {
        return f_merchant_settle_amount_ext;
    }

    public void setF_merchant_settle_amount_ext(Long f_merchant_settle_amount_ext) {
        this.f_merchant_settle_amount_ext = f_merchant_settle_amount_ext;
    }

    public String getF_order_id() {
        return f_order_id;
    }

    public void setF_order_id(String f_order_id) {
        this.f_order_id = f_order_id;
    }

    public Long getF_out_count() {
        return f_out_count;
    }

    public void setF_out_count(Long f_out_count) {
        this.f_out_count = f_out_count;
    }

    public String getF_royalty() {
        return f_royalty;
    }

    public void setF_royalty(String f_royalty) {
        this.f_royalty = f_royalty;
    }

    public Date getF_start_time() {
        return f_start_time;
    }

    public void setF_start_time(Date f_start_time) {
        this.f_start_time = f_start_time;
    }

    public Long getF_state() {
        return f_state;
    }

    public void setF_state(Long f_state) {
        this.f_state = f_state;
    }

    public Long getF_toagent_profit() {
        return f_toagent_profit;
    }

    public void setF_toagent_profit(Long f_toagent_profit) {
        this.f_toagent_profit = f_toagent_profit;
    }

    public Long getF_toagent_profit_ext() {
        return f_toagent_profit_ext;
    }

    public void setF_toagent_profit_ext(Long f_toagent_profit_ext) {
        this.f_toagent_profit_ext = f_toagent_profit_ext;
    }

    public Long getF_tome_profit() {
        return f_tome_profit;
    }

    public void setF_tome_profit(Long f_tome_profit) {
        this.f_tome_profit = f_tome_profit;
    }

    public Long getF_tome_profit_ext() {
        return f_tome_profit_ext;
    }

    public void setF_tome_profit_ext(Long f_tome_profit_ext) {
        this.f_tome_profit_ext = f_tome_profit_ext;
    }

    public Date getF_update_time() {
        return f_update_time;
    }

    public void setF_update_time(Date f_update_time) {
        this.f_update_time = f_update_time;
    }
}
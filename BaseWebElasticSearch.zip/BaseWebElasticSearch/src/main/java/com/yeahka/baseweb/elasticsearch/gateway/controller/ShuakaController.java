package com.yeahka.baseweb.elasticsearch.gateway.controller;

import com.yeahka.baseweb.elasticsearch.common.constant.RespEnum;
import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.common.util.StatisticUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.*;
import com.yeahka.baseweb.elasticsearch.module.shuaka.entity.ShuakaPosbillMerchantT1Bill;
import com.yeahka.baseweb.elasticsearch.module.shuaka.entity.ShuakaPosbillMerchantT1ChannelBill;
import com.yeahka.baseweb.elasticsearch.module.shuaka.service.ShuakaPosbillMerchantT1BillService;
import com.yeahka.baseweb.elasticsearch.module.shuaka.service.ShuakaPosbillMerchantT1ChannelBillService;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/shuaka")
public class ShuakaController extends AbstractController {

    @Autowired
    private ShuakaPosbillMerchantT1BillService shuakaPosbillMerchantT1BillService;
    @Autowired
    private ShuakaPosbillMerchantT1ChannelBillService shuakaPosbillMerchantT1ChannelBillService;

    @RequestMapping("/posbill/merchantT1Bill/query")
    @ResponseBody
    public RespDTO<ShuakaPosbillMerchantT1BillListDTO> queryPosbillMerchantT1Bill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<ShuakaPosbillMerchantT1Bill> shuakaPosbillMerchantT1BillIterable = shuakaPosbillMerchantT1BillService.query(commonQuery);
        ShuakaPosbillMerchantT1BillListDTO dto = new ShuakaPosbillMerchantT1BillListDTO();
        List<ShuakaPosbillMerchantT1Bill> list = new ArrayList<>();
        for (Iterator<ShuakaPosbillMerchantT1Bill> iterator = shuakaPosbillMerchantT1BillIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) shuakaPosbillMerchantT1BillIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/posbill/merchantT1Bill/statistic")
    @ResponseBody
    public RespDTO statisticPosbillMerchantT1Bill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = shuakaPosbillMerchantT1BillService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }

    @RequestMapping("/posbill/merchantT1ChannelBill/query")
    @ResponseBody
    public RespDTO<ShuakaPosbillMerchantT1ChannelBillListDTO> queryPosbillMerchantT1ChannelBill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<ShuakaPosbillMerchantT1ChannelBill> shuakaPosbillMerchantT1ChannelBillIterable = shuakaPosbillMerchantT1ChannelBillService.query(commonQuery);
        ShuakaPosbillMerchantT1ChannelBillListDTO dto = new ShuakaPosbillMerchantT1ChannelBillListDTO();
        List<ShuakaPosbillMerchantT1ChannelBill> list = new ArrayList<>();
        for (Iterator<ShuakaPosbillMerchantT1ChannelBill> iterator = shuakaPosbillMerchantT1ChannelBillIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) shuakaPosbillMerchantT1ChannelBillIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/posbill/merchantT1ChannelBill/statistic")
    @ResponseBody
    public RespDTO statisticPosbillMerchantT1ChannelBill(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = shuakaPosbillMerchantT1ChannelBillService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }
}
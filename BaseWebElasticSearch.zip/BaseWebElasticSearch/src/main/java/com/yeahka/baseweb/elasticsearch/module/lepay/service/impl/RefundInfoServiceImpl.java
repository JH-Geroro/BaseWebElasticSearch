package com.yeahka.baseweb.elasticsearch.module.lepay.service.impl;

import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.RefundInfo;
import com.yeahka.baseweb.elasticsearch.module.lepay.repository.RefundInfoRepository;
import com.yeahka.baseweb.elasticsearch.module.lepay.service.RefundInfoService;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Service;

@Service
public class RefundInfoServiceImpl implements RefundInfoService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;
    @Autowired
    private RefundInfoRepository refundInfoRepository;

    @Override
    public Page<RefundInfo> query(CommonQueryDTO commonQuery) {
        return refundInfoRepository.search(QueryUtil.convertQuery(commonQuery), PageRequest.of(commonQuery.getPageIndex(), commonQuery.getPageSize()));
    }

    @Override
    public Aggregations statistic(CommonQueryDTO commonQuery) {
        return elasticsearchTemplate.query(QueryUtil.convertStatistic(commonQuery, "lepay.t_refund_info", "_doc"), new ResultsExtractor<Aggregations>() {
            @Override
            public Aggregations extract(SearchResponse response) {
                return response.getAggregations();
            }
        });
    }
}
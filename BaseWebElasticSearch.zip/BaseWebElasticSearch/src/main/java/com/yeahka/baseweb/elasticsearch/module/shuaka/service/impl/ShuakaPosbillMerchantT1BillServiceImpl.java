package com.yeahka.baseweb.elasticsearch.module.shuaka.service.impl;

import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.shuaka.entity.ShuakaPosbillMerchantT1Bill;
import com.yeahka.baseweb.elasticsearch.module.shuaka.repository.ShuakaPosbillMerchantT1BillRepository;
import com.yeahka.baseweb.elasticsearch.module.shuaka.service.ShuakaPosbillMerchantT1BillService;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Service;

@Service
public class ShuakaPosbillMerchantT1BillServiceImpl implements ShuakaPosbillMerchantT1BillService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;
    @Autowired
    private ShuakaPosbillMerchantT1BillRepository shuakaPosbillMerchantT1BillRepository;

    public Page<ShuakaPosbillMerchantT1Bill> query(CommonQueryDTO commonQuery) {
        return shuakaPosbillMerchantT1BillRepository.search(QueryUtil.convertQuery(commonQuery), PageRequest.of(commonQuery.getPageIndex(), commonQuery.getPageSize()));
    }

    @Override
    public Aggregations statistic(CommonQueryDTO commonQuery) {
        return elasticsearchTemplate.query(QueryUtil.convertStatistic(commonQuery, "shuaka.posbill.t_merchant_t1_bill", "_doc"), new ResultsExtractor<Aggregations>() {
            @Override
            public Aggregations extract(SearchResponse response) {
                return response.getAggregations();
            }
        });
    }
}
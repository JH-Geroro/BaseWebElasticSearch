package com.yeahka.baseweb.elasticsearch.common.util;

import com.yeahka.baseweb.elasticsearch.common.constant.QueryTypeEnum;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.gateway.dto.QueryDataDTO;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.SumAggregationBuilder;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.net.URLDecoder;
import java.util.List;

public class QueryUtil {

    public static Boolean checkQuery(CommonQueryDTO commonQuery) {
        if (null == commonQuery) {
            return false;
        }
        if (!CollectionUtils.isEmpty(commonQuery.getQueryDataList())) {
            for (QueryDataDTO queryData : commonQuery.getQueryDataList()) {
                if (null == queryData.getType() || StringUtils.isEmpty(queryData.getKey())) {
                    return false;
                }
                QueryTypeEnum queryTypeEnum = QueryTypeEnum.parse(queryData.getType());
                if (null == queryTypeEnum) {
                    return false;
                }
                if (QueryTypeEnum.IN.equals(queryTypeEnum) || QueryTypeEnum.NOT_IN.equals(queryTypeEnum)) {
                    if (CollectionUtils.isEmpty(queryData.getValueList())) {
                        return false;
                    }
                } else {
                    if (StringUtils.isEmpty(queryData.getValue())) {
                        return false;
                    }
                }
            }
        }
        if (null == commonQuery.getPageIndex()) {
            commonQuery.setPageIndex(1);
        }
        if (null == commonQuery.getPageSize()) {
            commonQuery.setPageSize(10);
        }
        return true;
    }

    public static BoolQueryBuilder convertQuery(CommonQueryDTO commonQuery) {
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        BoolQueryBuilder shouldQuery = QueryBuilders.boolQuery();
        boolQueryBuilder.must(QueryBuilders.matchAllQuery());
        if (null != commonQuery && !CollectionUtils.isEmpty(commonQuery.getQueryDataList())) {
            for (QueryDataDTO queryData : commonQuery.getQueryDataList()) {
                if (null == queryData.getType() || StringUtils.isEmpty(queryData.getKey())) {
                    continue;
                }
                QueryTypeEnum queryTypeEnum = QueryTypeEnum.parse(queryData.getType());
                if (null != queryTypeEnum) {
                    if (QueryTypeEnum.IS_NOT.equals(queryTypeEnum)) {
                        if (!StringUtils.isEmpty(queryData.getValue())) {
                            try {
                                boolQueryBuilder.filter(QueryBuilders.boolQuery().mustNot(QueryBuilders.termQuery(queryData.getKey(), URLDecoder.decode(queryData.getValue(), "UTF-8"))));
                            } catch (Exception ex) {

                            }
                        }
                    } else if (QueryTypeEnum.IS.equals(queryTypeEnum)) {
                        if (!StringUtils.isEmpty(queryData.getValue())) {
                            try {
                                boolQueryBuilder.filter(QueryBuilders.boolQuery().must(QueryBuilders.termQuery(queryData.getKey(), URLDecoder.decode(queryData.getValue(), "UTF-8"))));
                            } catch (Exception ex) {

                            }
                        }
                    } else if (QueryTypeEnum.LIKE.equals(queryTypeEnum)) {
                        if (!StringUtils.isEmpty(queryData.getValue())) {
                            try {
                                boolQueryBuilder.filter(QueryBuilders.wildcardQuery(queryData.getKey(), "*" + URLDecoder.decode(queryData.getValue() + "*", "UTF-8")));
                            } catch (Exception ex) {

                            }
                        }
                    } else if (QueryTypeEnum.GREATER.equals(queryTypeEnum)) {
                        if (!StringUtils.isEmpty(queryData.getValue())) {
                            boolQueryBuilder.filter(QueryBuilders.rangeQuery(queryData.getKey()).from(queryData.getValue(), true));
                        }
                    } else if (QueryTypeEnum.LESS.equals(queryTypeEnum)) {
                        if (!StringUtils.isEmpty(queryData.getValue())) {
                            boolQueryBuilder.filter(QueryBuilders.rangeQuery(queryData.getKey()).to(queryData.getValue(), true));
                        }
                    } else if (QueryTypeEnum.IN.equals(queryTypeEnum)) {
                        if (!CollectionUtils.isEmpty(queryData.getValueList())) {
                            boolQueryBuilder.filter(QueryBuilders.boolQuery().must(QueryBuilders.termsQuery(queryData.getKey(), queryData.getValueList())));
                        }
                    } else if (QueryTypeEnum.NOT_IN.equals(queryTypeEnum)) {
                        if (!CollectionUtils.isEmpty(queryData.getValueList())) {
                            boolQueryBuilder.filter(QueryBuilders.boolQuery().mustNot(QueryBuilders.termsQuery(queryData.getKey(), queryData.getValueList())));
                        }
                    } else if(QueryTypeEnum.OR.equals(queryTypeEnum)){
                        if(!StringUtils.isEmpty(queryData.getKey()) && !StringUtils.isEmpty(queryData.getValue())){
                            shouldQuery.should(QueryBuilders.termsQuery(queryData.getKey(),queryData.getValue()));
                        }
                    }
                }
            }
        }
        boolQueryBuilder.must(shouldQuery);
        return boolQueryBuilder;
    }

    public static NativeSearchQuery convertStatistic(CommonQueryDTO commonQuery, String indices, String types) {
        NativeSearchQueryBuilder nativeSearchQueryBuilder = new NativeSearchQueryBuilder();
        BoolQueryBuilder boolQueryBuilder = convertQuery(commonQuery);
        NativeSearchQuery nativeSearchQuery = nativeSearchQueryBuilder.withQuery(boolQueryBuilder).withIndices(indices).withTypes(types).build();
        if (null != commonQuery && !CollectionUtils.isEmpty(commonQuery.getQueryDataList())) {
            for (QueryDataDTO queryData : commonQuery.getQueryDataList()) {
                if (null == queryData.getType() || StringUtils.isEmpty(queryData.getKey())) {
                    continue;
                }
                QueryTypeEnum queryTypeEnum = QueryTypeEnum.parse(queryData.getType());
                if (null != queryTypeEnum && QueryTypeEnum.SUM.equals(queryTypeEnum)) {
                    nativeSearchQuery.addAggregation(AggregationBuilders.sum(queryData.getValue()).field(queryData.getKey()));
                }
            }
        }
        return nativeSearchQuery;
    }
    public static NativeSearchQuery convertSum(CommonQueryDTO commonQuery, String indices, String types) {
        NativeSearchQueryBuilder nativeSearchQueryBuilder = new NativeSearchQueryBuilder();
        BoolQueryBuilder boolQueryBuilder = convertQuery(commonQuery);
        NativeSearchQuery nativeSearchQuery = nativeSearchQueryBuilder.withQuery(boolQueryBuilder).withIndices(indices).withTypes(types).build();
        TermsAggregationBuilder termsBuilder = AggregationBuilders.terms("f_merchant_id").field("f_merchant_id").size(100000);
        if (null != commonQuery && !CollectionUtils.isEmpty(commonQuery.getQueryDataList())) {
            for (QueryDataDTO queryData : commonQuery.getQueryDataList()) {
                if (null == queryData.getType() || StringUtils.isEmpty(queryData.getKey())) {
                    continue;
                }
                QueryTypeEnum queryTypeEnum = QueryTypeEnum.parse(queryData.getType());
                if (null != queryTypeEnum && QueryTypeEnum.SUM.equals(queryTypeEnum)) {
                    termsBuilder.subAggregation(AggregationBuilders.sum(queryData.getValue()).field(queryData.getKey()));
                }
            }
        }
        nativeSearchQuery.addAggregation(termsBuilder);
        return nativeSearchQuery;
    }


    public static NativeSearchQuery convertStat(CommonQueryDTO commonQuery, String indices, String types) {
        NativeSearchQueryBuilder nativeSearchQueryBuilder = new NativeSearchQueryBuilder();
        BoolQueryBuilder boolQueryBuilder = convertQuery(commonQuery);
        NativeSearchQuery nativeSearchQuery = nativeSearchQueryBuilder.withQuery(boolQueryBuilder).withIndices(indices).withTypes(types).build();
        TermsAggregationBuilder termsBuilder = AggregationBuilders.terms("f_merchant_id").field("f_merchant_id.keyword").size(commonQuery.getPageSize());
        if (!CollectionUtils.isEmpty(commonQuery.getQueryDataList())) {
            for (QueryDataDTO queryData : commonQuery.getQueryDataList()) {
                if (null == queryData.getType() || StringUtils.isEmpty(queryData.getKey())) {
                    continue;
                }
                QueryTypeEnum queryTypeEnum = QueryTypeEnum.parse(queryData.getType());
                if ( QueryTypeEnum.STAT.equals(queryTypeEnum)) {
                    termsBuilder.subAggregation(AggregationBuilders.stats(queryData.getValue()).field(queryData.getKey()));
                }
            }
        }
        nativeSearchQuery.addAggregation(termsBuilder);
        return nativeSearchQuery;
    }
}
package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OrderInfo;

import java.util.List;

public class OrderInfoListDTO extends BaseMeta {

    private Integer count;
    private List<OrderInfo> list;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<OrderInfo> getList() {
        return list;
    }

    public void setList(List<OrderInfo> list) {
        this.list = list;
    }
}
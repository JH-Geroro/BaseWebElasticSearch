package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.RefundInfo;

import java.util.List;

public class RefundInfoListDTO extends BaseMeta {

    private Integer count;
    private List<RefundInfo> list;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<RefundInfo> getList() {
        return list;
    }

    public void setList(List<RefundInfo> list) {
        this.list = list;
    }
}
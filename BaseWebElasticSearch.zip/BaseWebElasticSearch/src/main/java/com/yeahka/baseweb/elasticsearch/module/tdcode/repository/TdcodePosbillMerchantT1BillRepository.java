package com.yeahka.baseweb.elasticsearch.module.tdcode.repository;

import com.yeahka.baseweb.elasticsearch.module.tdcode.entity.TdcodePosbillMerchantT1Bill;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface TdcodePosbillMerchantT1BillRepository extends ElasticsearchRepository<TdcodePosbillMerchantT1Bill, Long> {

    public Page<TdcodePosbillMerchantT1Bill> search(QueryBuilder queryBuilder, Pageable pageable);
}
package com.yeahka.baseweb.elasticsearch.common.constant;

public interface CommonConstant {

    String REQUEST_METHOD_GET = "GET";
    String REQUEST_METHOD_POST = "POST";
    String DEFAULT_CHARSET = "UTF-8";
}
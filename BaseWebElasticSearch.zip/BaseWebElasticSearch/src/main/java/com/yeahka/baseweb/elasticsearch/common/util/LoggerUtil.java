package com.yeahka.baseweb.elasticsearch.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggerUtil {

    private static final Logger accessLogger = LoggerFactory.getLogger("ACCESS");
    private static final Logger monitorLogger = LoggerFactory.getLogger("MONITOR");

    public static void writeAccessLog(String content, Object... args) {
        accessLogger.info(content, args);
    }

    public static void writeMonitorLog(String content, Object... args) {
        monitorLogger.info(content, args);
    }
}
package com.yeahka.baseweb.elasticsearch.module.lepay.service.impl;

import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OrderInfo;
import com.yeahka.baseweb.elasticsearch.module.lepay.repository.OrderInfoRepository;
import com.yeahka.baseweb.elasticsearch.module.lepay.service.OrderInfoService;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Service;

@Service
public class OrderInfoServiceImpl implements OrderInfoService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;
    @Autowired
    private OrderInfoRepository orderInfoRepository;

    @Override
    public Page<OrderInfo> query(CommonQueryDTO commonQuery) {
        return orderInfoRepository.search(QueryUtil.convertQuery(commonQuery), PageRequest.of(commonQuery.getPageIndex(), commonQuery.getPageSize()));
    }

    @Override
    public Aggregations statistic(CommonQueryDTO commonQuery) {
        return elasticsearchTemplate.query(QueryUtil.convertStatistic(commonQuery, "lepay.t_order_info", "_doc"), new ResultsExtractor<Aggregations>() {
            @Override
            public Aggregations extract(SearchResponse response) {
                return response.getAggregations();
            }
        });
    }
}
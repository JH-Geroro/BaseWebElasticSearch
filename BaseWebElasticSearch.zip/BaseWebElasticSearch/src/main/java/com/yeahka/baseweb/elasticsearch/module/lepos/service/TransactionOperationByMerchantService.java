package com.yeahka.baseweb.elasticsearch.module.lepos.service;

import com.yeahka.baseweb.elasticsearch.gateway.dto.CommonQueryDTO;
import com.yeahka.baseweb.elasticsearch.module.lepos.entity.TransactionOperationByMerchant;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.data.domain.Page;

public interface TransactionOperationByMerchantService {

    public Page<TransactionOperationByMerchant> query(CommonQueryDTO commonQuery);

    public Aggregations statistic(CommonQueryDTO commonQuery);

    public Aggregations sum(CommonQueryDTO commonQuery);
}
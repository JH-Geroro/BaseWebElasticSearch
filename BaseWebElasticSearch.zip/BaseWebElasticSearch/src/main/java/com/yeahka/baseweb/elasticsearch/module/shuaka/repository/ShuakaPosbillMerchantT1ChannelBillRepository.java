package com.yeahka.baseweb.elasticsearch.module.shuaka.repository;

import com.yeahka.baseweb.elasticsearch.module.shuaka.entity.ShuakaPosbillMerchantT1ChannelBill;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

@Component
public interface ShuakaPosbillMerchantT1ChannelBillRepository extends ElasticsearchRepository<ShuakaPosbillMerchantT1ChannelBill, Long> {

    public Page<ShuakaPosbillMerchantT1ChannelBill> search(QueryBuilder queryBuilder, Pageable pageable);
}
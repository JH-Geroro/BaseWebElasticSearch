package com.yeahka.baseweb.elasticsearch.gateway.controller;

import com.alibaba.fastjson.JSON;
import com.yeahka.baseweb.elasticsearch.common.constant.RespEnum;
import com.yeahka.baseweb.elasticsearch.common.util.QueryUtil;
import com.yeahka.baseweb.elasticsearch.common.util.StatisticUtil;
import com.yeahka.baseweb.elasticsearch.gateway.dto.*;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OperationInfo;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.OrderInfo;
import com.yeahka.baseweb.elasticsearch.module.lepay.entity.RefundInfo;
import com.yeahka.baseweb.elasticsearch.module.lepay.service.OperationInfoService;
import com.yeahka.baseweb.elasticsearch.module.lepay.service.OrderInfoService;
import com.yeahka.baseweb.elasticsearch.module.lepay.service.RefundInfoService;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequestMapping("/lepay")
public class LepayController extends AbstractController {

    @Autowired
    private OperationInfoService operationInfoService;
    @Autowired
    private OrderInfoService orderInfoService;
    @Autowired
    private RefundInfoService refundInfoService;

    @RequestMapping("/operationInfo/query")
    @ResponseBody
    public RespDTO<OperationInfoListDTO> queryOperationInfo(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<OperationInfo> operationInfoInfoIterable = operationInfoService.query(commonQuery);
        System.out.println(JSON.toJSONString(operationInfoInfoIterable));
        OperationInfoListDTO dto = new OperationInfoListDTO();
        List<OperationInfo> list = new ArrayList<>();
        for (Iterator<OperationInfo> iterator = operationInfoInfoIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount( operationInfoInfoIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/operationInfo/statistic")
    @ResponseBody
    public RespDTO statisticOperationInfo(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = operationInfoService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }

    @RequestMapping("/orderInfo/query")
    @ResponseBody
    public RespDTO<OrderInfoListDTO> queryOrderInfo(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<OrderInfo> orderInfoIterable = orderInfoService.query(commonQuery);
        OrderInfoListDTO dto = new OrderInfoListDTO();
        List<OrderInfo> list = new ArrayList<>();
        for (Iterator<OrderInfo> iterator = orderInfoIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) orderInfoIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/orderInfo/statistic")
    @ResponseBody
    public RespDTO statisticOrderInfo(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = orderInfoService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }

    @RequestMapping("/refundInfo/query")
    @ResponseBody
    public RespDTO<RefundInfoListDTO> queryRefundInfo(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Page<RefundInfo> refundInfoIterable = refundInfoService.query(commonQuery);
        RefundInfoListDTO dto = new RefundInfoListDTO();
        List<RefundInfo> list = new ArrayList<>();
        for (Iterator<RefundInfo> iterator = refundInfoIterable.iterator(); iterator.hasNext(); ) {
            list.add(iterator.next());
        }
        dto.setCount((int) refundInfoIterable.getTotalElements());
        dto.setList(list);
        return new RespDTO(RespEnum.SUCCESS, dto);
    }

    @RequestMapping("/refundInfo/statistic")
    @ResponseBody
    public RespDTO statisticRefundInfo(@RequestBody CommonQueryDTO commonQuery) {
        if (!QueryUtil.checkQuery(commonQuery)) {
            return new RespDTO(RespEnum.PARAMETER_ERROR);
        }
        Aggregations aggregations = refundInfoService.statistic(commonQuery);
        return new RespDTO(RespEnum.SUCCESS, StatisticUtil.convertStatisticDTO(aggregations));
    }
}
package com.yeahka.baseweb.elasticsearch.gateway.dto;

import com.yeahka.baseweb.elasticsearch.common.constant.RespEnum;
import com.yeahka.baseweb.elasticsearch.common.dto.BoResult;
import com.yeahka.baseweb.elasticsearch.common.entity.BaseMeta;

public class RespDTO<T extends BaseMeta> extends BaseMeta {

    private Integer code;
    private T data;
    private String message;

    public RespDTO(RespEnum respEnum) {
        this.code = respEnum.getCode();
        this.data = null;
        this.message = respEnum.getMessage();
    }

    public RespDTO(RespEnum respEnum, T data) {
        this.code = respEnum.getCode();
        this.data = data;
        this.message = respEnum.getMessage();
    }

    public RespDTO(BoResult<T> boResult) {
        this.code = boResult.getCode();
        this.data = boResult.getData();
        this.message = boResult.getMessage();
    }

    public RespDTO(Integer code, T data, String message) {
        this.code = code;
        this.data = data;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
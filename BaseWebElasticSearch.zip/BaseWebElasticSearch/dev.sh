#!/bin/bash
cd `dirname $0`
basepath=$(cd `dirname $0`; pwd)
git pull
pid=`ps -ef|grep baseweb-elasticsearch-0.0.1-SNAPSHOT|grep -v "grep"|awk -F ' ' '{print $2}'`
kill $pid
mvn clean package -DskipTests
nohup /usr/local/jdk1.8.0_161/bin/java -Xmx512m -jar target/baseweb-elasticsearch-0.0.1-SNAPSHOT.jar --spring.profiles.active=dev >/dev/null 2>&1 &